create database DXC
use[DXC]

CREATE TABLE Cust_details
(
Name varchar(64) NOT NULL,
Email varchar(64) NOT NULL,
Phone_num bigint NOT NULL,
WAstatusUpdate varchar(64),
EmailUpdate varchar(64),
)

INSERT INTO [Cust_details] VALUES ('King','waynugopal@yahoo.com', '9440544100','','')
INSERT INTO [Cust_details] VALUES ('Queen','sreelucksheme@gmail.com', '9346614806','','')
INSERT INTO [Cust_details] VALUES ('raja','kopparthisravya94@gmail.com', '7893509203','','')
INSERT INTO [Cust_details] VALUES ('rani','anjanakopparthi@gmail.com', '8179179812','','')
INSERT INTO [Cust_details] VALUES ('John','John@gmail.com', '1234567890','','')

CREATE TABLE ConfigWA
(
ConfigName varchar(64) NOT NULL,
ConfigValue NText NOT NULL,
)
INSERT INTO [ConfigWA] VALUES ('WAweb','https://web.whatsapp.com/')
INSERT INTO [ConfigWA] VALUES ('WAwebLink','https://api.whatsapp.com/send?phone=')
INSERT INTO [ConfigWA] VALUES ('CountryCode','91')
INSERT INTO [ConfigWA] VALUES ('WAimgLoc', '"C:\Users\akopparthi\OneDrive - DXC Production\Documents\UiPath\for project\WA image.jpg"')
INSERT INTO [ConfigWA] VALUES ('xlCustDetails', '"C:\Users\akopparthi\OneDrive - DXC Production\Documents\UiPath\for project\CustomerList.xlsx"')
INSERT INTO [ConfigWA] VALUES ('SheetName', 'Sheet1')
INSERT INTO [ConfigWA] VALUES ('EntryCell', 'D')

CREATE TABLE ConfigMail
(
ConfigName varchar(64) NOT NULL,
ConfigValue NText NOT NULL,
)
INSERT INTO [ConfigMail] VALUES ('Subject','Launch of GM Mobile')
INSERT INTO [ConfigMail] VALUES ('Body','"Dear {0}<br><br>Greetings!<br><br>The new Mobile you are waiting for GM Mobile is available from 3pm Wednesday 12-Aug for sale @
greatshopping.com<img src=phone.jpg><br>Enjoy Happy Shopping!<br>Team Great Shopping."')
INSERT INTO [ConfigMail] VALUES ('FilePath','"C:\Users\akopparthi\OneDrive - DXC Production\Documents\UiPath\for project\phone.jpg"')
INSERT INTO [ConfigMail] VALUES ('EntryCell','E')


